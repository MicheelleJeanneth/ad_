﻿namespace TH_02
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtbox1 = new System.Windows.Forms.TextBox();
            this.txtbox2 = new System.Windows.Forms.TextBox();
            this.txtbox3 = new System.Windows.Forms.TextBox();
            this.txtbox4 = new System.Windows.Forms.TextBox();
            this.txtbox5 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonQ = new System.Windows.Forms.Button();
            this.buttonW = new System.Windows.Forms.Button();
            this.buttonE = new System.Windows.Forms.Button();
            this.buttonR = new System.Windows.Forms.Button();
            this.buttonT = new System.Windows.Forms.Button();
            this.buttonY = new System.Windows.Forms.Button();
            this.buttonU = new System.Windows.Forms.Button();
            this.buttonI = new System.Windows.Forms.Button();
            this.buttonO = new System.Windows.Forms.Button();
            this.buttonP = new System.Windows.Forms.Button();
            this.buttonA = new System.Windows.Forms.Button();
            this.buttonS = new System.Windows.Forms.Button();
            this.buttonD = new System.Windows.Forms.Button();
            this.buttonF = new System.Windows.Forms.Button();
            this.buttonG = new System.Windows.Forms.Button();
            this.buttonH = new System.Windows.Forms.Button();
            this.buttonJ = new System.Windows.Forms.Button();
            this.buttonK = new System.Windows.Forms.Button();
            this.buttonL = new System.Windows.Forms.Button();
            this.buttonZ = new System.Windows.Forms.Button();
            this.buttonX = new System.Windows.Forms.Button();
            this.buttonC = new System.Windows.Forms.Button();
            this.buttonV = new System.Windows.Forms.Button();
            this.buttonB = new System.Windows.Forms.Button();
            this.buttonN = new System.Windows.Forms.Button();
            this.buttonM = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.lblChoose = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtbox1
            // 
            this.txtbox1.Location = new System.Drawing.Point(105, 15);
            this.txtbox1.Name = "txtbox1";
            this.txtbox1.Size = new System.Drawing.Size(119, 26);
            this.txtbox1.TabIndex = 0;
            // 
            // txtbox2
            // 
            this.txtbox2.Location = new System.Drawing.Point(105, 47);
            this.txtbox2.Name = "txtbox2";
            this.txtbox2.Size = new System.Drawing.Size(119, 26);
            this.txtbox2.TabIndex = 1;
            // 
            // txtbox3
            // 
            this.txtbox3.Location = new System.Drawing.Point(105, 79);
            this.txtbox3.Name = "txtbox3";
            this.txtbox3.Size = new System.Drawing.Size(119, 26);
            this.txtbox3.TabIndex = 2;
            // 
            // txtbox4
            // 
            this.txtbox4.Location = new System.Drawing.Point(105, 111);
            this.txtbox4.Name = "txtbox4";
            this.txtbox4.Size = new System.Drawing.Size(119, 26);
            this.txtbox4.TabIndex = 3;
            // 
            // txtbox5
            // 
            this.txtbox5.Location = new System.Drawing.Point(105, 143);
            this.txtbox5.Name = "txtbox5";
            this.txtbox5.Size = new System.Drawing.Size(119, 26);
            this.txtbox5.TabIndex = 4;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(105, 184);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 49);
            this.button1.TabIndex = 5;
            this.button1.Text = "Play !";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.txtbox5);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.txtbox4);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txtbox3);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.txtbox2);
            this.panel1.Controls.Add(this.txtbox1);
            this.panel1.Location = new System.Drawing.Point(48, 27);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(240, 244);
            this.panel1.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 146);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(86, 20);
            this.label5.TabIndex = 11;
            this.label5.Text = "5th Word : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 114);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 20);
            this.label4.TabIndex = 10;
            this.label4.Text = "4th Word : ";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 82);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 20);
            this.label3.TabIndex = 9;
            this.label3.Text = "3rd Word : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 20);
            this.label2.TabIndex = 8;
            this.label2.Text = "2nd Word : ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 20);
            this.label1.TabIndex = 7;
            this.label1.Text = "1st Word : ";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // buttonQ
            // 
            this.buttonQ.BackColor = System.Drawing.Color.Lavender;
            this.buttonQ.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonQ.ForeColor = System.Drawing.SystemColors.MenuText;
            this.buttonQ.Location = new System.Drawing.Point(9, 110);
            this.buttonQ.Name = "buttonQ";
            this.buttonQ.Size = new System.Drawing.Size(69, 60);
            this.buttonQ.TabIndex = 7;
            this.buttonQ.Text = "Q";
            this.buttonQ.UseVisualStyleBackColor = false;
            this.buttonQ.Click += new System.EventHandler(this.a1_Click);
            // 
            // buttonW
            // 
            this.buttonW.BackColor = System.Drawing.Color.Lavender;
            this.buttonW.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.buttonW.ForeColor = System.Drawing.SystemColors.ControlText;
            this.buttonW.Location = new System.Drawing.Point(84, 110);
            this.buttonW.Name = "buttonW";
            this.buttonW.Size = new System.Drawing.Size(69, 60);
            this.buttonW.TabIndex = 8;
            this.buttonW.Text = "W";
            this.buttonW.UseVisualStyleBackColor = false;
            this.buttonW.Click += new System.EventHandler(this.a2_Click);
            // 
            // buttonE
            // 
            this.buttonE.BackColor = System.Drawing.Color.Lavender;
            this.buttonE.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.buttonE.Location = new System.Drawing.Point(159, 110);
            this.buttonE.Name = "buttonE";
            this.buttonE.Size = new System.Drawing.Size(69, 60);
            this.buttonE.TabIndex = 9;
            this.buttonE.Text = "E";
            this.buttonE.UseVisualStyleBackColor = false;
            this.buttonE.Click += new System.EventHandler(this.a3_Click);
            // 
            // buttonR
            // 
            this.buttonR.BackColor = System.Drawing.Color.Lavender;
            this.buttonR.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.buttonR.Location = new System.Drawing.Point(234, 110);
            this.buttonR.Name = "buttonR";
            this.buttonR.Size = new System.Drawing.Size(69, 60);
            this.buttonR.TabIndex = 10;
            this.buttonR.Text = "R";
            this.buttonR.UseVisualStyleBackColor = false;
            this.buttonR.Click += new System.EventHandler(this.a4_Click);
            // 
            // buttonT
            // 
            this.buttonT.BackColor = System.Drawing.Color.Lavender;
            this.buttonT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.buttonT.Location = new System.Drawing.Point(309, 110);
            this.buttonT.Name = "buttonT";
            this.buttonT.Size = new System.Drawing.Size(69, 60);
            this.buttonT.TabIndex = 11;
            this.buttonT.Text = "T";
            this.buttonT.UseVisualStyleBackColor = false;
            this.buttonT.Click += new System.EventHandler(this.a5_Click);
            // 
            // buttonY
            // 
            this.buttonY.BackColor = System.Drawing.Color.Lavender;
            this.buttonY.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.buttonY.Location = new System.Drawing.Point(384, 110);
            this.buttonY.Name = "buttonY";
            this.buttonY.Size = new System.Drawing.Size(69, 60);
            this.buttonY.TabIndex = 12;
            this.buttonY.Text = "Y";
            this.buttonY.UseVisualStyleBackColor = false;
            this.buttonY.Click += new System.EventHandler(this.a6_Click);
            // 
            // buttonU
            // 
            this.buttonU.BackColor = System.Drawing.Color.Lavender;
            this.buttonU.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.buttonU.Location = new System.Drawing.Point(459, 110);
            this.buttonU.Name = "buttonU";
            this.buttonU.Size = new System.Drawing.Size(69, 60);
            this.buttonU.TabIndex = 13;
            this.buttonU.Text = "U";
            this.buttonU.UseVisualStyleBackColor = false;
            this.buttonU.Click += new System.EventHandler(this.a7_Click);
            // 
            // buttonI
            // 
            this.buttonI.BackColor = System.Drawing.Color.Lavender;
            this.buttonI.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.buttonI.Location = new System.Drawing.Point(534, 110);
            this.buttonI.Name = "buttonI";
            this.buttonI.Size = new System.Drawing.Size(69, 60);
            this.buttonI.TabIndex = 14;
            this.buttonI.Text = "I";
            this.buttonI.UseVisualStyleBackColor = false;
            this.buttonI.Click += new System.EventHandler(this.a8_Click);
            // 
            // buttonO
            // 
            this.buttonO.BackColor = System.Drawing.Color.Lavender;
            this.buttonO.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.buttonO.Location = new System.Drawing.Point(609, 110);
            this.buttonO.Name = "buttonO";
            this.buttonO.Size = new System.Drawing.Size(69, 60);
            this.buttonO.TabIndex = 15;
            this.buttonO.Text = "O";
            this.buttonO.UseVisualStyleBackColor = false;
            this.buttonO.Click += new System.EventHandler(this.a9_Click);
            // 
            // buttonP
            // 
            this.buttonP.BackColor = System.Drawing.Color.Lavender;
            this.buttonP.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.buttonP.Location = new System.Drawing.Point(684, 110);
            this.buttonP.Name = "buttonP";
            this.buttonP.Size = new System.Drawing.Size(69, 60);
            this.buttonP.TabIndex = 16;
            this.buttonP.Text = "P";
            this.buttonP.UseVisualStyleBackColor = false;
            this.buttonP.Click += new System.EventHandler(this.a10_Click);
            // 
            // buttonA
            // 
            this.buttonA.BackColor = System.Drawing.Color.Lavender;
            this.buttonA.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.buttonA.Location = new System.Drawing.Point(21, 176);
            this.buttonA.Name = "buttonA";
            this.buttonA.Size = new System.Drawing.Size(69, 60);
            this.buttonA.TabIndex = 17;
            this.buttonA.Text = "A";
            this.buttonA.UseVisualStyleBackColor = false;
            this.buttonA.Click += new System.EventHandler(this.a11_Click);
            // 
            // buttonS
            // 
            this.buttonS.BackColor = System.Drawing.Color.Lavender;
            this.buttonS.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.buttonS.Location = new System.Drawing.Point(96, 176);
            this.buttonS.Name = "buttonS";
            this.buttonS.Size = new System.Drawing.Size(69, 60);
            this.buttonS.TabIndex = 18;
            this.buttonS.Text = "S";
            this.buttonS.UseVisualStyleBackColor = false;
            this.buttonS.Click += new System.EventHandler(this.a12_Click);
            // 
            // buttonD
            // 
            this.buttonD.BackColor = System.Drawing.Color.Lavender;
            this.buttonD.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.buttonD.Location = new System.Drawing.Point(171, 176);
            this.buttonD.Name = "buttonD";
            this.buttonD.Size = new System.Drawing.Size(69, 60);
            this.buttonD.TabIndex = 19;
            this.buttonD.Text = "D";
            this.buttonD.UseVisualStyleBackColor = false;
            this.buttonD.Click += new System.EventHandler(this.a13_Click);
            // 
            // buttonF
            // 
            this.buttonF.BackColor = System.Drawing.Color.Lavender;
            this.buttonF.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.buttonF.Location = new System.Drawing.Point(246, 176);
            this.buttonF.Name = "buttonF";
            this.buttonF.Size = new System.Drawing.Size(69, 60);
            this.buttonF.TabIndex = 20;
            this.buttonF.Text = "F";
            this.buttonF.UseVisualStyleBackColor = false;
            this.buttonF.Click += new System.EventHandler(this.a14_Click);
            // 
            // buttonG
            // 
            this.buttonG.BackColor = System.Drawing.Color.Lavender;
            this.buttonG.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.buttonG.Location = new System.Drawing.Point(321, 176);
            this.buttonG.Name = "buttonG";
            this.buttonG.Size = new System.Drawing.Size(69, 60);
            this.buttonG.TabIndex = 21;
            this.buttonG.Text = "G";
            this.buttonG.UseVisualStyleBackColor = false;
            this.buttonG.Click += new System.EventHandler(this.a15_Click);
            // 
            // buttonH
            // 
            this.buttonH.BackColor = System.Drawing.Color.Lavender;
            this.buttonH.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.buttonH.Location = new System.Drawing.Point(396, 176);
            this.buttonH.Name = "buttonH";
            this.buttonH.Size = new System.Drawing.Size(69, 60);
            this.buttonH.TabIndex = 22;
            this.buttonH.Text = "H";
            this.buttonH.UseVisualStyleBackColor = false;
            this.buttonH.Click += new System.EventHandler(this.a16_Click);
            // 
            // buttonJ
            // 
            this.buttonJ.BackColor = System.Drawing.Color.Lavender;
            this.buttonJ.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.buttonJ.Location = new System.Drawing.Point(471, 176);
            this.buttonJ.Name = "buttonJ";
            this.buttonJ.Size = new System.Drawing.Size(69, 60);
            this.buttonJ.TabIndex = 23;
            this.buttonJ.Text = "J";
            this.buttonJ.UseVisualStyleBackColor = false;
            this.buttonJ.Click += new System.EventHandler(this.a17_Click);
            // 
            // buttonK
            // 
            this.buttonK.BackColor = System.Drawing.Color.Lavender;
            this.buttonK.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.buttonK.Location = new System.Drawing.Point(546, 176);
            this.buttonK.Name = "buttonK";
            this.buttonK.Size = new System.Drawing.Size(69, 60);
            this.buttonK.TabIndex = 24;
            this.buttonK.Text = "K";
            this.buttonK.UseVisualStyleBackColor = false;
            this.buttonK.Click += new System.EventHandler(this.a18_Click);
            // 
            // buttonL
            // 
            this.buttonL.BackColor = System.Drawing.Color.Lavender;
            this.buttonL.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.buttonL.Location = new System.Drawing.Point(621, 176);
            this.buttonL.Name = "buttonL";
            this.buttonL.Size = new System.Drawing.Size(69, 60);
            this.buttonL.TabIndex = 25;
            this.buttonL.Text = "L";
            this.buttonL.UseVisualStyleBackColor = false;
            this.buttonL.Click += new System.EventHandler(this.a19_Click);
            // 
            // buttonZ
            // 
            this.buttonZ.BackColor = System.Drawing.Color.Lavender;
            this.buttonZ.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.buttonZ.Location = new System.Drawing.Point(59, 242);
            this.buttonZ.Name = "buttonZ";
            this.buttonZ.Size = new System.Drawing.Size(69, 60);
            this.buttonZ.TabIndex = 26;
            this.buttonZ.Text = "Z";
            this.buttonZ.UseVisualStyleBackColor = false;
            this.buttonZ.Click += new System.EventHandler(this.a20_Click);
            // 
            // buttonX
            // 
            this.buttonX.BackColor = System.Drawing.Color.Lavender;
            this.buttonX.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.buttonX.Location = new System.Drawing.Point(134, 242);
            this.buttonX.Name = "buttonX";
            this.buttonX.Size = new System.Drawing.Size(69, 60);
            this.buttonX.TabIndex = 27;
            this.buttonX.Text = "X";
            this.buttonX.UseVisualStyleBackColor = false;
            this.buttonX.Click += new System.EventHandler(this.a21_Click);
            // 
            // buttonC
            // 
            this.buttonC.BackColor = System.Drawing.Color.Lavender;
            this.buttonC.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.buttonC.Location = new System.Drawing.Point(209, 242);
            this.buttonC.Name = "buttonC";
            this.buttonC.Size = new System.Drawing.Size(69, 60);
            this.buttonC.TabIndex = 28;
            this.buttonC.Text = "C";
            this.buttonC.UseVisualStyleBackColor = false;
            this.buttonC.Click += new System.EventHandler(this.a22_Click);
            // 
            // buttonV
            // 
            this.buttonV.BackColor = System.Drawing.Color.Lavender;
            this.buttonV.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.buttonV.Location = new System.Drawing.Point(284, 242);
            this.buttonV.Name = "buttonV";
            this.buttonV.Size = new System.Drawing.Size(69, 60);
            this.buttonV.TabIndex = 29;
            this.buttonV.Text = "V";
            this.buttonV.UseVisualStyleBackColor = false;
            this.buttonV.Click += new System.EventHandler(this.a23_Click);
            // 
            // buttonB
            // 
            this.buttonB.BackColor = System.Drawing.Color.Lavender;
            this.buttonB.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.buttonB.Location = new System.Drawing.Point(359, 242);
            this.buttonB.Name = "buttonB";
            this.buttonB.Size = new System.Drawing.Size(69, 60);
            this.buttonB.TabIndex = 30;
            this.buttonB.Text = "B";
            this.buttonB.UseVisualStyleBackColor = false;
            this.buttonB.Click += new System.EventHandler(this.a24_Click);
            // 
            // buttonN
            // 
            this.buttonN.BackColor = System.Drawing.Color.Lavender;
            this.buttonN.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.buttonN.Location = new System.Drawing.Point(434, 242);
            this.buttonN.Name = "buttonN";
            this.buttonN.Size = new System.Drawing.Size(69, 60);
            this.buttonN.TabIndex = 31;
            this.buttonN.Text = "N";
            this.buttonN.UseVisualStyleBackColor = false;
            this.buttonN.Click += new System.EventHandler(this.a25_Click);
            // 
            // buttonM
            // 
            this.buttonM.BackColor = System.Drawing.Color.Lavender;
            this.buttonM.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.buttonM.Location = new System.Drawing.Point(509, 242);
            this.buttonM.Name = "buttonM";
            this.buttonM.Size = new System.Drawing.Size(69, 60);
            this.buttonM.TabIndex = 32;
            this.buttonM.Text = "M";
            this.buttonM.UseVisualStyleBackColor = false;
            this.buttonM.Click += new System.EventHandler(this.a26_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.lblChoose);
            this.panel2.Controls.Add(this.buttonM);
            this.panel2.Controls.Add(this.buttonN);
            this.panel2.Controls.Add(this.buttonB);
            this.panel2.Controls.Add(this.buttonV);
            this.panel2.Controls.Add(this.buttonC);
            this.panel2.Controls.Add(this.buttonX);
            this.panel2.Controls.Add(this.buttonZ);
            this.panel2.Controls.Add(this.buttonL);
            this.panel2.Controls.Add(this.buttonK);
            this.panel2.Controls.Add(this.buttonJ);
            this.panel2.Controls.Add(this.buttonH);
            this.panel2.Controls.Add(this.buttonG);
            this.panel2.Controls.Add(this.buttonF);
            this.panel2.Controls.Add(this.buttonD);
            this.panel2.Controls.Add(this.buttonS);
            this.panel2.Controls.Add(this.buttonA);
            this.panel2.Controls.Add(this.buttonP);
            this.panel2.Controls.Add(this.buttonO);
            this.panel2.Controls.Add(this.buttonI);
            this.panel2.Controls.Add(this.buttonU);
            this.panel2.Controls.Add(this.buttonY);
            this.panel2.Controls.Add(this.buttonT);
            this.panel2.Controls.Add(this.buttonR);
            this.panel2.Controls.Add(this.buttonE);
            this.panel2.Controls.Add(this.buttonW);
            this.panel2.Controls.Add(this.buttonQ);
            this.panel2.Location = new System.Drawing.Point(135, 27);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(762, 316);
            this.panel2.TabIndex = 33;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(627, 47);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 25);
            this.label6.TabIndex = 33;
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // lblChoose
            // 
            this.lblChoose.AutoSize = true;
            this.lblChoose.Font = new System.Drawing.Font("Microsoft Sans Serif", 34F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChoose.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblChoose.Location = new System.Drawing.Point(228, 8);
            this.lblChoose.Name = "lblChoose";
            this.lblChoose.Size = new System.Drawing.Size(304, 78);
            this.lblChoose.TabIndex = 12;
            this.lblChoose.Text = "_ _ _ _ _";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1213, 450);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Guess The Word - TH02 Micheelle";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtbox1;
        private System.Windows.Forms.TextBox txtbox2;
        private System.Windows.Forms.TextBox txtbox3;
        private System.Windows.Forms.TextBox txtbox4;
        private System.Windows.Forms.TextBox txtbox5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button buttonQ;
        private System.Windows.Forms.Button buttonW;
        private System.Windows.Forms.Button buttonE;
        private System.Windows.Forms.Button buttonR;
        private System.Windows.Forms.Button buttonT;
        private System.Windows.Forms.Button buttonY;
        private System.Windows.Forms.Button buttonU;
        private System.Windows.Forms.Button buttonI;
        private System.Windows.Forms.Button buttonO;
        private System.Windows.Forms.Button buttonP;
        private System.Windows.Forms.Button buttonA;
        private System.Windows.Forms.Button buttonS;
        private System.Windows.Forms.Button buttonD;
        private System.Windows.Forms.Button buttonF;
        private System.Windows.Forms.Button buttonG;
        private System.Windows.Forms.Button buttonH;
        private System.Windows.Forms.Button buttonJ;
        private System.Windows.Forms.Button buttonK;
        private System.Windows.Forms.Button buttonL;
        private System.Windows.Forms.Button buttonZ;
        private System.Windows.Forms.Button buttonX;
        private System.Windows.Forms.Button buttonC;
        private System.Windows.Forms.Button buttonV;
        private System.Windows.Forms.Button buttonB;
        private System.Windows.Forms.Button buttonN;
        private System.Windows.Forms.Button buttonM;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblChoose;
        private System.Windows.Forms.Label label6;
    }
}

