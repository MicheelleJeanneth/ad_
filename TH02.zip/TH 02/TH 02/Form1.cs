﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace TH_02
{
    public partial class Form1 : Form
    {
        string chooseword;
        public Form1()
        {
            InitializeComponent();
            panel2.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<string> listword = new List<string>(); 
            int k1 = Convert.ToInt32(txtbox1.Text.Length);
            int k2 = Convert.ToInt32(txtbox2.Text.Length);
            int k3 = Convert.ToInt32(txtbox3.Text.Length);
            int k4 = Convert.ToInt32(txtbox4.Text.Length);
            int k5 = Convert.ToInt32(txtbox5.Text.Length);

            int a = 0;
            char errornama;
            errornama = 'n';

            for (int i = 0; i < txtbox1.Text.Length; i++)
            {
                if (txtbox1.Text[i] == '1' || txtbox1.Text[i] == '2' || txtbox1.Text[i] == '3' || txtbox1.Text[i] == '4' || txtbox1.Text[i] == '5' || txtbox1.Text[i] == '6' || txtbox1.Text[i] == '7' || txtbox1.Text[i] == '8' || txtbox1.Text[i] == '9' || txtbox1.Text[i] == '0')
                {
                    errornama = 'y';
                }
                else if (txtbox2.Text[i] == '1' || txtbox2.Text[i] == '2' || txtbox2.Text[i] == '3' || txtbox2.Text[i] == '4' || txtbox2.Text[i] == '5' || txtbox2.Text[i] == '6' || txtbox2.Text[i] == '7' || txtbox2.Text[i] == '8' || txtbox2.Text[i] == '9' || txtbox2.Text[i] == '0')
                {
                    errornama = 'y';
                }
                else
                    if (txtbox3.Text[i] == '1' || txtbox3.Text[i] == '2' || txtbox3.Text[i] == '3' || txtbox3.Text[i] == '4' || txtbox3.Text[i] == '5' || txtbox3.Text[i] == '6' || txtbox3.Text[i] == '7' || txtbox3.Text[i] == '8' || txtbox3.Text[i] == '9' || txtbox3.Text[i] == '0')
                {
                    errornama = 'y';
                }
                else if (txtbox4.Text[i] == '1' || txtbox4.Text[i] == '2' || txtbox4.Text[i] == '3' || txtbox4.Text[i] == '4' || txtbox4.Text[i] == '5' || txtbox4.Text[i] == '6' || txtbox4.Text[i] == '7' || txtbox4.Text[i] == '8' || txtbox4.Text[i] == '9' || txtbox4.Text[i] == '0')
                {
                    errornama = 'y';
                }
                else if (txtbox5.Text[i] == '1' || txtbox5.Text[i] == '2' || txtbox5.Text[i] == '3' || txtbox5.Text[i] == '4' || txtbox5.Text[i] == '5' || txtbox5.Text[i] == '6' || txtbox5.Text[i] == '7' || txtbox5.Text[i] == '8' || txtbox5.Text[i] == '9' || txtbox5.Text[i] == '0')
                {
                    errornama = 'y';
                }
            }
            if (k1 != 5 || k2 != 5 || k3 != 5 || k4 != 5 || k5 != 5)
            {
                MessageBox.Show("There's still an error");
            }
            else if (errornama == 'y')
            {
                MessageBox.Show("No usage of number in input");
            }
            else if (txtbox1.Text == txtbox2.Text || txtbox1.Text == txtbox3.Text || txtbox1.Text == txtbox4.Text|| txtbox1.Text == txtbox5.Text
                     || txtbox2.Text == txtbox3.Text || txtbox2.Text == txtbox4.Text || txtbox2.Text == txtbox5.Text || txtbox3.Text == txtbox4.Text 
                     || txtbox3.Text == txtbox5.Text || txtbox4.Text == txtbox5.Text) 
            {
                MessageBox.Show("There's still same words");
            }
            else
            {
                MessageBox.Show("Let's play !");
                panel1.Visible = false;
                panel2.Visible = true;

                listword.Add(txtbox1.Text);
                listword.Add(txtbox2.Text);
                listword.Add(txtbox3.Text);
                listword.Add(txtbox4.Text);
                listword.Add(txtbox5.Text);

                Random random = new Random();
                int guess = random.Next(0, 5);

                chooseword = listword[guess].ToUpper();
                label6.Text = listword[guess];
            }
        }

        public void CekHuruf (char Huruf)
        {
            int ke = 1;
            for (int j = 0; j < 5; j++)
            {
                if (chooseword[j] == Huruf)
                {
                    ke = j * 2;
                    lblChoose.Text = lblChoose.Text.Remove(ke, 1);
                    lblChoose.Text = lblChoose.Text.Insert(ke, Convert.ToString(Huruf));
                }
            }
            if (lblChoose.Text.Replace(" ", "") == chooseword)
            {
                MessageBox.Show("You Win !");
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void a1_Click(object sender, EventArgs e)
        {
            CekHuruf('Q');
        }

        private void a2_Click(object sender, EventArgs e)
        {
            CekHuruf('W');
        }

        private void a3_Click(object sender, EventArgs e)
        {
            CekHuruf('E'); 
        }

        private void a4_Click(object sender, EventArgs e)
        {
            CekHuruf('R');
        }

        private void a5_Click(object sender, EventArgs e)
        {
            CekHuruf('T');
        }

        private void a6_Click(object sender, EventArgs e)
        {
            CekHuruf('Y');
        }

        private void a7_Click(object sender, EventArgs e)
        {
            CekHuruf('U');
        }

        private void a8_Click(object sender, EventArgs e)
        {
            CekHuruf('I');
        }

        private void a9_Click(object sender, EventArgs e)
        {
            CekHuruf('O');
        }

        private void a10_Click(object sender, EventArgs e)
        {
            CekHuruf('P');
        }

        private void a11_Click(object sender, EventArgs e)
        {
            CekHuruf('A');
        }

        private void a12_Click(object sender, EventArgs e)
        {
            CekHuruf('S');
        }

        private void a13_Click(object sender, EventArgs e)
        {
            CekHuruf('D');
        }

        private void a14_Click(object sender, EventArgs e)
        {
            CekHuruf('F');
        }

        private void a15_Click(object sender, EventArgs e)
        {
            CekHuruf('G');
        }

        private void a16_Click(object sender, EventArgs e)
        {
            CekHuruf('H');
        }

        private void a17_Click(object sender, EventArgs e)
        {
            CekHuruf('J');
        }

        private void a18_Click(object sender, EventArgs e)
        {
            CekHuruf('K');
        }

        private void a19_Click(object sender, EventArgs e)
        {
            CekHuruf('L');
        }

        private void a20_Click(object sender, EventArgs e)
        {
            CekHuruf('Z');
        }

        private void a21_Click(object sender, EventArgs e)
        {
            CekHuruf('X');
        }

        private void a22_Click(object sender, EventArgs e)
        {
            CekHuruf('C');
        }

        private void a23_Click(object sender, EventArgs e)
        {
            CekHuruf('V');
        }

        private void a24_Click(object sender, EventArgs e)
        {
            CekHuruf('B');
        }

        private void a25_Click(object sender, EventArgs e)
        {
            CekHuruf('N');
        }

        private void a26_Click(object sender, EventArgs e)
        {
            CekHuruf('M');
        }

        private void label6_Click(object sender, EventArgs e)
        {
            
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
